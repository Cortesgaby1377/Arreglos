/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

/**
 *
 * @author EQUIPO-PC
 */
public class funciones {
     String word;

    public String getWord() {
        return word;
    }
     public void setWord(String word) {
        this.word = word.toLowerCase();
    }
    
    private String sust(){
        String nword=word;
        int poslr=0, numla=0;
        char let;
        for (int i = 0; i < word.length(); i++) {
            int c=0;
            for (int j = 0; j < word.length(); j++) {            
                if (word.charAt(i)==word.charAt(j)){
                    c++;
                }
            }
            if (numla<c) {
                numla=c;
                poslr=i;
            }
        }
        let=word.charAt(poslr);
        if (numla==1){
            return nword;
        }
        for (int i = 0; i < nword.length(); i++) {
            char l = nword.charAt(i);
            if (l=='a'||l=='e'||l=='i'||l=='o'||l=='u') {
                nword=nword.replace(l, let);
            }
        }
        return nword;

    }
    
    public String getSust(){
        return sust();
    }
    
    
    public String getInvert(){
        return invert();
       
    }
    private String invert(){
        String nword="";
        for (int i = 0; i < word.length(); i++) {
            nword=word.charAt(i)+nword;
        }
        return nword;
    }
}



