
package ejercicio.pkg2;

import java.util.Scanner;

/**
 *
 * @author EQUIPO-PC
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        String word;
        funciones func=new funciones();
        Scanner scan=new Scanner(System.in);
        System.out.println(" Linea de caracteres: ");
        word=scan.nextLine();
        func.setWord(word);
        while(true){
            System.out.println("\n 1. Sustituir.\n 2. Invertir.\n 3. Salir");
            int op=scan.nextInt();
            switch(op){
                case 1:
                    System.out.println(func.getSust());
                    continue;
                case 2:
                    System.out.println(func.getInvert());
                    continue;
                case 3:
                    break;
                default:
                    System.out.println("Opcion invalida");
                    continue;
            }
            break;
        }
    }
    
}