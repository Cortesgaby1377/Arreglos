 
 
package metodosordenamiento;
import java.util.Random;
import java.util.Scanner;

public class Metodos {


public void Burbuja(int array[])
	{

        long Tiempoinicial=System.nanoTime();
        System.out.println("BURBUJA");
		int n = array.length;
		for (int i = 0; i < n - 1; i++)
			for (int j = 0; j < n - i - 1; j++)
				if (array[j] > array[j + 1]) {
					// swap arr[j+1] and arr[j]
					int temporal = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temporal;
				}
                 for (int i = 0; i < array.length; i++) {
             System.out.print(array[i]+", ");
         }
         System.out.println("");
         long Tiempofinal=System.nanoTime();
         System.out.println("El tiempo del metodo de Burbuja es: "+(Tiempofinal-Tiempoinicial )+" nanosegundos");
	}


	void seleccion(int array[])
	{
             long Tiempoinicial=System.nanoTime();
        System.out.println("Seleccion");
		int n = array.length;

		
		for (int i = 0; i < n-1; i++)
		{
			
			int min_idx = i;
			for (int j = i+1; j < n; j++)
				if (array[j] < array[min_idx])
					min_idx = j;

			
			int temp = array[min_idx];
			array[min_idx] = array[i];
			array[i] = temp;
		}
                for (int i = 0; i < array.length; i++) {
             System.out.print(array[i]+", ");
         }
         System.out.println("");
         long Tiempofinal=System.nanoTime();
         System.out.println("El tiempo del metodo de seleccion  es: "+(Tiempofinal-Tiempoinicial)+" nanosegundos");
	}

	
	
      
	void Insercion(int array[])
	{
             long Tiempoinicial=System.nanoTime();
        System.out.println("Seleccion");
		int n = array.length;
		for (int i = 1; i < n; ++i) {
			int key = array[i];
			int j = i - 1;

			while (j >= 0 && array[j] > key) {
				array[j + 1] = array[j];
				j = j - 1;
			}
			array[j + 1] = key;
		}
                for (int i = 0; i < array.length; i++) {
             System.out.print(array[i]+", ");
         }
         System.out.println("");
         long Tiempofinal=System.nanoTime();
         System.out.println("El tiempo del metodo de Insercion es: "+(Tiempofinal-Tiempoinicial)+" nanosegundos");
	}

	
	
	
public void mergesort(int arreglo[], int primero, int ultimo){
         
        int mitad;
        
        if (primero<ultimo){
            mitad=(primero+ultimo)/2;
            mergesort (arreglo, primero, mitad);
            mergesort (arreglo, mitad+1, ultimo);
            mezcla (arreglo, primero, mitad, ultimo);
        }
    }
    
    public void mezcla (int [] arreglo, int left, int middle, int right){
       
        double aux []= new double [arreglo.length];
        int x, y, z;
        
        x=z=left;
        
        y=middle+1;
        
        while (x<=middle && y<=right){
            
            if (arreglo[x]<=arreglo[y]){
                aux[z++]=arreglo[x++];
            }
            else {
                aux[z++]=arreglo[y++];
            }
        }
        
        while (x<=middle){
            
            aux[z++]=arreglo[x++];
        }
        
        while (y<=right){
            
            aux[z++]=arreglo[y++];
        }
        
        
        
    }
    
   
  
	
	
	
};

     




