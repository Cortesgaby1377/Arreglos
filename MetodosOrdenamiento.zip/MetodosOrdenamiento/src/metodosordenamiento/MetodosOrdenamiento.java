
package metodosordenamiento;
import java.util.*;
public class MetodosOrdenamiento {

    
    public static void main(String[] args) {
      Metodos ordenamiento=new Metodos();
        Scanner scan=new Scanner(System.in);
        System.out.println("¿Cual es el tamaño del arreglo?");
        int []numeros=new int[scan.nextInt()];
        int primero= 0;
        int ultimo = numeros.length-1;
        Random ran=new Random();
        for (int i = 0; i < numeros.length; i++) {
            numeros[i]=ran.nextInt(10000);
            System.out.println(numeros[i]);
        }
       
        ordenamiento.Burbuja(numeros);
        ordenamiento.Insercion(numeros);
        ordenamiento.seleccion(numeros);
        ordenamiento.mergesort(numeros,primero,ultimo);
        
        
        //Tiempo del Mergesort 
        long Tiempoinicial=System.nanoTime();
         System.out.println("MERGE");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print(numeros[i]+", ");
        }
        System.out.println("");
        long Tiempofinal=System.nanoTime();
        System.out.println("El tiempo del metodo MergeSort es: "+(Tiempofinal-Tiempoinicial)+" nanosegundos");
            System.out.println("");
    }
    
}
