
package ejercicio1;

import java.util.Arrays;

/**
 *
 * @author EQUIPO-PC
 */
public class funciones {
    int[]nom;
 
    public void pr(){
        for (int i:nom) {
            System.out.print(i+" ");
        }
    }
     private double mediana(){
        Arrays.sort(nom);
        int med=nom.length/2;
        if (nom.length%2==0){
            return(double)(nom[med-1]+nom[med])/2;
        } else {
            return nom[med];
        }
    }
    private double med(){
        int sum=0;
        for (int i : nom) {
            sum +=i;
        }
        return (double)sum/nom.length;
    }
    
   
    
    private double varia(){
        double med=med(), sum=0;
        for (int i: nom) {
            sum += Math.pow(i-med, 2);
        }
        return sum/nom.length;
    }
    
    private double desvEst(){
        return Math.sqrt(varia());
    }
    
    private int mod(){
        int moda=nom[0];
        int max=0;
        for (int i:nom) {
            int c = 0;
            for (int j : nom) {
                if (i==j) {
                    c++;
                }
            }
            if (c>max) {
                moda=i;
                max=c;
            }
        }
        return moda;
    }

    public int[] getNom() {
        return nom;
    }

    public void setNom(int[] nom) {
        this.nom = nom;
    }
      public double getMediana() {
        return mediana();
    }
     public double getMod() {
        return mod();
    }
    public double getMedia() {
        return med();
    }
  
    public double getVar() {
        return varia();
    }
    public double getDesv() {
        return desvEst();
    }
   
}

