/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author EQUIPO-PC
 */
public class Ejercicio1 {

 public static void main(String[] args) {
        funciones func=new funciones();     
        Scanner scan=new Scanner(System.in);
        System.out.println(" Tamaño arreglo: ");
        int[]num=new int[scan.nextInt()];
        Random ra = new Random();
        for (int i = 0; i < num.length; i++) {
            num[i]= ra.nextInt(100);
        }
        func.setNom(num);
        func.pr();
        while(true){
            int op=0;
            System.out.println("\n 1. Media y mediana \n 2. Varia \n 3. Desviacion estandar\n 4. Moda\n 5. Salir\n");
            System.out.println(" Opciones : ");
            op=scan.nextInt();
            switch(op){
                case 1:
                    System.out.println(" Media: "+func.getMedia()+"\n mediana: "+func.getMediana());
                    continue;
                case 2:
                    System.out.println(" Varianza: "+func.getVar());
                    continue;
                case 3:
                    System.out.println(" Desviacion estandar: "+func.getDesv());
                    continue;
                case 4:
                    System.out.println(" Moda: "+func.getMod());
                    continue;
                case 5:
                    break;
                default:
                    System.out.println(" Opcion invalida");
                    continue;              
            }
            break;
        }     
                // TODO code application logic here
    }
    
    ;
      
}
